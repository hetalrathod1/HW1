public class PersonalDetails
{
    static String name = "chirag";
    static int age = 18;
    static  int day = 01;
    static String month = "february";
    static int year = 1983;
    static  String add = "116 whittington way,pinner";
    static String postcode = "HA5 5JX";
    public static void main (String args[])
    {
        System.out.println("age ="+age);
        System.out.println("dob ="+day+"/"+month+"/"+year);
       // System.out.println(month);
        //System.out.println(year);
        System.out.println("address="+add);
        System.out.println("post code="+postcode);

    }

}
